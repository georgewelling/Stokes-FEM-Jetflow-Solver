function [] = fem_plot_nodes(Space);

  plot(Space.x(:,1),Space.x(:,2),'o')

